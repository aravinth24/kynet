<style type="text/css">
	*.infobox{
		width: 100% !important;
	}
	.highcharts-credits{
		display: none;
	}
</style>
<div class="col-sm-6">
	<div class="widget-box" >
		<div class="widget-header widget-header-flat widget-header-small">
			<h5 class="widget-title">
				<i class="ace-icon fa fa-signal"></i>
				Total Employee 
			</h5>

		</div>

		<div class="widget-body">
			<div class="widget-main">
				<div class="infobox infobox-blue">
					<div class="infobox-icon">
						<i class="ace-icon fa fa-users"></i>
					</div>

					<div class="infobox-data">
						<span class="infobox-data-number">32 Permanent	</span>
						<div class="infobox-content"></div>
					</div>
					<div class="stat stat-success" style="margin-right:10%">30%</div>
					<div class="stat stat-important" margin-left:10%>2%</div>
				</div>
				<hr/>
				<div class="infobox infobox-green">
					<div class="infobox-icon">
						<i class="ace-icon fa fa-users"></i>
					</div>

					<div class="infobox-data">
						<span class="infobox-data-number">11 Daily Wager</span>
						<div class="infobox-content"></div>
					</div>
					<div class="stat stat-success" style="margin-right:10%">10%</div>
					<div class="stat stat-important" margin-left:10%>1%</div>
					
				</div>
				<hr/>
				<div class="infobox infobox-pink">
					<div class="infobox-icon">
						<i class="ace-icon fa fa-users"></i>
					</div>

					<div class="infobox-data">
						<span class="infobox-data-number">18 Contract</span>
						<div class="infobox-content"></div>
					</div>
					<div class="stat stat-success" style="margin-right:10%">12%</div>
					<div class="stat stat-important" margin-left:10%>6%</div>
				</div>
			</div>
		</div><!-- /.widget-body -->
	</div><!-- /.widget-box -->
</div>

<div class="col-sm-6">
	<div class="widget-box">
		<div class="widget-header widget-header-flat widget-header-small">
			<h5 class="widget-title">
				<i class="ace-icon fa fa-signal"></i>
				Employee Types
			</h5>

		</div>

		<div class="widget-body">
			<div class="widget-main">
				<div id="chartdiv"></div>
			</div>
		</div><!-- /.widget-body -->
	</div><!-- /.widget-box -->
</div>

<script type="text/javascript">
	Highcharts.setOptions({
     colors: ['#6FB3E0', '#9ABC32', '#CB6FD7']
    });
    var chart;

	chart = new Highcharts.chart('chartdiv', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
         height: 300,
    },
    title: {
        text: ''
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
   plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            showInLegend: true
        }
    },
    series: [{
        name: 'Types',
        colorByPoint: true,
        data: [{
            name: 'Permanent',
            y: 60,
            sliced: true,
            selected: true,
        }, {
            name: 'Daily Wager',
            y: 20
        }, {
            name: 'Contract',
            y: 20
        }]
    }]
});

</script>