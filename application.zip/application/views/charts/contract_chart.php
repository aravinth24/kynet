<style type="text/css">
	.infobox{
		width: 100% !important;
	}
	/*.widget-box{
		height: 380px !important;
		width: 100% !important;
	}*/
	.highcharts-credits{
		display: none;
	}
</style>
<div class="col-sm-6">
	<div class="widget-box" >
		<div class="widget-header widget-header-flat widget-header-small">
			<h5 class="widget-title">
				<i class="ace-icon fa fa-signal"></i>
				Contract Employee - Monthly Report  
			</h5>

		</div>

		<div class="widget-body">
			<div class="widget-main">
				<div id="contract_bar" style="height: 300px; min-width: 320px; max-width: 600px; margin: 0 auto"></div>

			</div>
		</div><!-- /.widget-body -->
	</div><!-- /.widget-box -->
</div>

<div class="col-sm-6">
	<div class="widget-box">
		<div class="widget-header widget-header-flat widget-header-small">
			<h5 class="widget-title">
				<i class="ace-icon fa fa-signal"></i>
				Contract Employee - Monthly Report  
			</h5>

		</div>

		<div class="widget-body">
			<div class="widget-main">
				<div id="contract_graph" ></div>
			</div>
		</div><!-- /.widget-body -->
	</div><!-- /.widget-box -->
</div>

<script type="text/javascript">
	

Highcharts.chart('contract_bar', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'robin',
            'vijay',
            'dev',
            'mike'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'days'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y} days</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    
    series: [{
        name: 'No of days present',
        data: [20, 25, 28, 15]

    }, {
        name: 'No of days absent',
        data: [10, 5, 2, 15]

    },
    ]
});


Highcharts.chart('contract_graph', {
	 chart: {
       height:300
    },
    title: {
        text: ''
    },
     xAxis: {	labels:{
                        enabled:false//default is true
                    }		 },
    yAxis: {
        min: 1,
        max: 30,
    },
    /*legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },*/

    plotOptions: {
        series: {
            label: {
                connectorAllowed: false
            },
            pointStart: 1
        }
    },

    series: [{
        name: 'Robin',
        data: [10,8,20, 28]
    }, {
        name: 'vijay',
        data: [12,24,27]
    },
     {
        name: 'dev',
        data: [15,30,14]
    },
    {
        name: 'mike',
        data: [19,16,29]
    }],
});
</script>