<div class="panel panel-default">
    <div class="panel-heading" style="color:#669FC7">
        <i class="ace-icon fa fa-signal"></i>
        Today's Report (<?php echo date('d-m-Y')?>) 
    </div>
    <div class="panel-body">
        <div class="col-md-4" id="gauge_1"></div>
        <div class="col-md-4" id="gauge_2"></div>
        <div class="col-md-4" id="gauge_3"></div>
    </div>
</div>


<script type="text/javascript">
var per_total_emp = <?php echo ($result['permanent']['total_emp']!='0')?$result['permanent']['total_emp']:'10';?>;

if(per_total_emp!='0')
{
    var per_total_pre   = <?php echo $result['permanent']['total_present']?>;
    var per_total_abs   = <?php echo ($result['permanent']['total_absent']!='0')?$result['permanent']['total_absent']:$result['permanent']['total_present']?>;
}
else
{
    var per_total_pre = '0';
    var per_total_abs = '0';
}

var con_total_emp = <?php echo ($result['contract']['total_emp']!='0')?$result['contract']['total_emp']:'10';?>;
if(con_total_emp!='0')
{
    var con_total_pre   = <?php echo$result['contract']['total_present'];?>;
    var con_total_abs   = <?php echo ($result['contract']['total_absent']!='0')?$result['contract']['total_absent']:$result['contract']['total_present']?>;
}
else
{
    var con_total_pre = '0';
    var con_total_abs = '0';
}

var daily_total_emp = <?php echo ($result['daily_wager']['total_emp']!='0')?$result['daily_wager']['total_emp']:'10';?>;
if(daily_total_emp!='0')
{
    var daily_total_pre     = <?php echo$result['daily_wager']['total_present'];?>;
    var daily_total_abs   = <?php echo ($result['daily_wager']['total_absent']!='0')?$result['daily_wager']['total_absent']:$result['daily_wager']['total_present']?>;
}
else
{
    var daily_total_pre = '0';
    var daily_total_abs = '0';
}

Highcharts.chart('gauge_1', {
    chart: {
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        height: 300
    },

    title: {
        text: 'Permanent'
    },

    pane: {
        startAngle: -150,
        endAngle: 150,
        background: [{
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#FFF'],
                    [1, '#333']
                ]
            },
            borderWidth: 0,
            outerRadius: '109%'
        }, {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#333'],
                    [1, '#FFF']
                ]
            },
            borderWidth: 1,
            outerRadius: '107%'
        }, {
            // default background
        }, {
            backgroundColor: '#DDD',
            borderWidth: 0,
            outerRadius: '105%',
            innerRadius: '103%'
        }]
    },

    // the value axis
    yAxis: {
        allowDecimals: false,
        min: 0,
        max: per_total_emp,
        minorTickInterval: 'auto',
        minorTickWidth: 1,
        minorTickLength: 10,
        minorTickPosition: 'inside',
        minorTickColor: '#666',

        tickPixelInterval: 30,
        tickWidth: 2,
        tickPosition: 'inside',
        tickLength: 10,
        tickColor: '#666',
        labels: {
            step: 2,
            rotation: 'auto'
        },
        title: {
            text: 'present'
        },
        plotBands: [{
            from: 0,
            to: per_total_pre,
            color: '#55BF3B' // green
        }, {
            from: per_total_pre,
            to: per_total_abs,
            color: '#DF5353' // red
        },
         {
            from: per_total_pre,
            to: per_total_emp,
            color: '#FFFF00' // yellow
        }]
    },

    series: [{
        name: 'Speed',
        data: [per_total_pre],
        tooltip: {
            valueSuffix: ' present'
        }
    }]

});

///////Second Gauge//////////
Highcharts.chart('gauge_2', {
    chart: {
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        height: 300
    },

    title: {
        text: 'Daily Wager'
    },

    pane: {
        startAngle: -150,
        endAngle: 150,
        background: [{
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#FFF'],
                    [1, '#333']
                ]
            },
            borderWidth: 0,
            outerRadius: '109%'
        }, {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#333'],
                    [1, '#FFF']
                ]
            },
            borderWidth: 1,
            outerRadius: '107%'
        }, {
            // default background
        }, {
            backgroundColor: '#DDD',
            borderWidth: 0,
            outerRadius: '105%',
            innerRadius: '103%'
        }]
    },

    // the value axis
    yAxis: {
        allowDecimals: false,
        min: 0,
        max: con_total_emp,
        minorTickInterval: 'auto',
        minorTickWidth: 1,
        minorTickLength: 10,
        minorTickPosition: 'inside',
        minorTickColor: '#666',

        tickPixelInterval: 30,
        tickWidth: 2,
        tickPosition: 'inside',
        tickLength: 10,
        tickColor: '#666',
        labels: {
            step: 2,
            rotation: 'auto'
        },
        title: {
            text: 'present'
        },
        plotBands: [{
           from: 0,
            to: con_total_pre,
            color: '#55BF3B' // green
        }, {
            from: con_total_pre,
            to: con_total_abs,
            color: '#DF5353' // red
        },
        {
            from: con_total_abs,
            to: con_total_emp,
            color: '#FFFF00' // yellow
        }
        ]
    },

    series: [{
        name: 'Speed',
        data: [con_total_pre],
        tooltip: {
            valueSuffix: ' present'
        }
    }]

});

///////Third Gauge////////
Highcharts.chart('gauge_3', {
    chart: {
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        height: 300
    },

    title: {
        text: 'Contract'
    },

    pane: {
        startAngle: -150,
        endAngle: 150,
        background: [{
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#FFF'],
                    [1, '#333']
                ]
            },
            borderWidth: 0,
            outerRadius: '109%'
        }, {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
                    [0, '#333'],
                    [1, '#FFF']
                ]
            },
            borderWidth: 1,
            outerRadius: '107%'
        }, {
            // default background
        }, {
            backgroundColor: '#DDD',
            borderWidth: 0,
            outerRadius: '105%',
            innerRadius: '103%'
        }]
    },

    // the value axis
    yAxis: {
        allowDecimals: false,
        min: 0,
        max: daily_total_emp,
        minorTickInterval: 'auto',
        minorTickWidth: 1,
        minorTickLength: 10,
        minorTickPosition: 'inside',
        minorTickColor: '#666',

        tickPixelInterval: 30,
        tickWidth: 2,
        tickPosition: 'inside',
        tickLength: 10,
        tickColor: '#666',
        labels: {
            step: 2,
            rotation: 'auto'
        },
        title: {
            text: 'present'
        },
        plotBands: [{
           from: 0,
            to: daily_total_pre,
            color: '#55BF3B' // green
        }, {
            from: daily_total_pre,
            to: daily_total_abs,
            color: '#DF5353' // red
        },
        {
            from: daily_total_abs,
            to: daily_total_emp,
            color: '#FFFF00' // yellow
        }
        ]
    },

    series: [{
        name: 'Speed',
        data: [daily_total_pre],
        tooltip: {
            valueSuffix: ' present'
        }
    }]

});
</script>