<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta charset="utf-8">
		<title>Kyenet</title>
		<meta name="description" content="User login page">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/4.5.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/fonts.googleapis.com.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-rtl.min.css">
		<style type="text/css">
			.profile{
				font-size: 18px;
			}
			.error_msg{
				color: red;
			}
		</style>
	</head>
<body class="no-skin">
		
<?php $this->load->view('template/header');?>
		<div class="main-container ace-save-state" id="main-container">
			
			<?php $this->load->view('template/sidebar');?>
				
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1>
								<?php echo @$parent;?>
								<?php if(@$child!=''){?>
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									<?php echo $child;?>
								</small>
								<?php } ?>
							</h1>
						</div>

						<div class="row">
							<div class="col-xs-12">
								<form id="dept_form" name="dept_form" method="post" class="col-md-8">
								    <div class="form-group">
								      <label for="department">Department Name:</label>
								      <input type="text" class="form-control" id="department" placeholder="Enter department" name="department" required>
								    </div>
								   <div class="form-group">
								      <label for="department">Department Desciption:</label>
								      <textarea class="form-control" placeholder="Enter Desciption" id="desc" name="desc" required></textarea>
								    </div>
								    <button type="submit" class="btn btn-default">Submit</button>
								</form>
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			<?php $this->load->view('template/footer');?>

				<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
				</a>
		</div><!-- /.main-container -->
	</body>

<!--[if !IE]> -->
<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript">
	if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.custom.min.js"></script>	
<script src="<?php echo base_url();?>assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url();?>assets/js/ace.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>

<script type="text/javascript">
	$("#dept_form").validate({
		errorClass:'error_msg',
		rules:
		{
			department:
			{
				required: true
			},
			desc:
			{
				required: true
			},
		},
		messages:
		{
			department:
			{
				required: 'Please enter a department name'
			},
			desc:
			{
				required: 'Please enter a department description'
			},
		},
		submitHandler: function(form) {
			 $.ajax({
				type:"POST",
				data:$("#dept_form").serialize(),
				url:"<?php echo base_url('department/insert_dept')?>",
				success: function (res) {
					alert('New depatment has been added successfully');
					window.location.reload();
				}
			});
			 return false; 
		}
	});
</script>
</html>