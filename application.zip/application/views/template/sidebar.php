<div id="sidebar" class="sidebar responsive ace-save-state">
	<ul class="nav nav-list">
		<li class="<?php echo (@$parent=='Dashboard')?'open active':''; ?>">
			<a href="<?php echo base_url('admin/dashboard')?>">
				<i class="menu-icon fa fa-tachometer"></i>
				<span class="menu-text">
					Dashboard	
				</span>
			</a>

			<b class="arrow"></b>
		</li>
		<li class="<?php echo (@$parent=='Add Employee')?'open active':''; ?>">
			<a href="<?php echo base_url('employee/add_employee')?>">
				<i class="menu-icon fa fa-users"></i>
				<span class="menu-text">
					Add Employee
				</span>
			</a>

			<b class="arrow"></b>
		</li>
		<li class="<?php echo (@$parent=='Add Department')?'open active':''; ?>">
			<a href="<?php echo base_url('department/add_department')?>">
				<i class="menu-icon fa fa-cogs"></i>
				<span class="menu-text">
					Add Department
				</span>
			</a>

			<b class="arrow"></b>
		</li>
		<li class="<?php echo (@$parent=='Department')?'open active':''; ?>">
			<a href="#" class="dropdown-toggle">
				<i class="menu-icon fa fa-desktop"></i>
				<span class="menu-text">
					Departments
				</span>

				<b class="arrow fa fa-angle-down"></b>
			</a>

			<b class="arrow"></b>

			<ul class="submenu">
				<?php foreach($menu as $m){?>
				<li class="<?php echo (@$child==$m['dept_name'])?'open active':''; ?>">
					<a href="<?php echo base_url('department/content/'.$m['dept_name'].'/'.base64_encode($m['id']))?>">
						<i class="menu-icon fa fa-caret-right"></i>
						<?php echo $m['dept_name'];?>
					</a>

					<b class="arrow"></b>
				</li>
				<?php }?>
			
					<b class="arrow"></b>
				</li>
			</ul>
		</li>					
		
	</ul><!-- /.nav-list -->

	<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
		<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
	</div>
</div>
