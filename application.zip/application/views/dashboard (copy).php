<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta charset="utf-8">
		<title>Kyenet</title>
		<meta name="description" content="User login page">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/4.5.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/fonts.googleapis.com.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-rtl.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/split_screen.css">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

		<script src="<?php echo base_url();?>assets/charts/highcharts.js"></script>
		<script src="<?php echo base_url();?>assets/charts/highcharts-more.js"></script>
		<script src="<?php echo base_url();?>assets/charts/highstock.js"></script>
		<script src="<?php echo base_url();?>assets/charts/series-label.js"></script>		
		<style type="text/css">
			.highcharts-credits{
				display: none;
			}
		</style>
	</head>
	<body class="no-skin">		
		<?php $this->load->view('template/header');?>
		<div class="main-container ace-save-state" id="main-container">
			<?php $this->load->view('template/sidebar');?>				
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1>
								<?php echo @$parent;?>
								<?php if(@$child!=''){?>
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									<?php echo $child;?>
								</small>
								<?php } ?>
							</h1>
						</div>

						<div class="row">
							<div class="col-xs-12">
								<div class="row">
									<div class="col-xs-12">
										<?php $this->load->view('charts/gauge_chart');?>
										<?php $this->load->view('charts/pie_chart');?>
										<?php $this->load->view('charts/permanent_chart');?>
										<?php $this->load->view('charts/daily_wager_chart');?>
										<?php $this->load->view('charts/contract_chart');?>
										<?php $this->load->view('employee_list'); ?>
									</div><!-- /.span -->
								</div><!-- /.row -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
			<?php $this->load->view('template/footer');?>
			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->
	</body>

	<!--[if !IE]> -->
	<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript">
		if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
	</script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery-ui.custom.min.js"></script>	
	<script src="<?php echo base_url();?>assets/js/ace-elements.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/ace.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function() {
		var otable 	= $('#example').DataTable({
				   		"processing": true,
				   		"ajax": {
						            "url": '<?php echo base_url();?>admin/ajax_data',
						            "type": "POST",
						            data:{  
							         		category: function()
							               	{
							                	return $('#sel1').val();
							               	}
							            },
						},
				    	"columns": [
					        	{ "data": "id" },
					        	{ "data": "username" },
					        	{ 
					        		mRender: function(data, type, full){
					        			var text = '';
					        			switch(full['usertype'])
					        			{
					        				case '0':
					        					text = 'Permanent';
					        				break;
					        				case '1':
					        					text = 'Contract';
					        				break;
					        				case '2':
					        					text = 'Daily Wager';
					        				break;
					        			}
					        			return text;
					        			//return  'ok';
					        		} 
					        	},
					        	{ 
					        		mRender: function(data, type, full){
					        			return (full['date']=='null')?'Absent':'Present';
					        		} 
					        	}
						]
				   	});

		$("#sel1").on('change',function()
		{
			switch(this.value)
			{
				case '0':
					text = 'Permanent';
				break;
				case '1':
					text = 'Contract';
				break;
				case '2':
					text = 'Daily Wager';
				break;
			}
			otable.columns( 2 )
			      .search( text )
			      .draw();
		});
	});
	</script>
</html>