<div class="col-sm-12">
   <div class="row" style="margin-top:2%;"> 
      <div class="form-group">
         <div class="col-sm-4">
            <select class="form-control" id="sel1">
               <option value="">Select list</option>
               <option value="0">Permanent</option>
               <option value="1">Contract</option>
               <option value="2">Daily Wager</option>
            </select>
         </div>
      </div>
   </div>
   <div class="row" style="margin-top:2%;">
         <table id="example" class="table table-striped table-bordered nowrap" width="100%">
         <thead>
            <tr>
               <th>Employee Id</th>
               <th>Employee Name</th>
               <th>Employee Type</th>
               <th>Attendance</th>
            </tr>
         </thead>
         <tbody>
            
         </tbody>
      </table>
   </div>
</div>

      