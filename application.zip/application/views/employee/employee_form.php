<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta charset="utf-8">
	<title>Login Page - Ace Admin</title>
	<meta name="description" content="User login page">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<!-- bootstrap & fontawesome -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/fonts.googleapis.com.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-rtl.min.css">
	<style type="text/css">
		.profile{
			font-size: 18px;
		}
			.form_row{
				padding: 5%;
			}
			.wrapper {
		    text-align: center;
		}

		.button {
		    position: absolute;
		    top: 50%;
		}
		.error_msg, .error
		{
			color: red;
		}
	</style>
	<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script>
</head>

<body class="no-skin">
	<?php $this->load->view('template/header');?>

	<div class="main-container ace-save-state" id="main-container">
		
		<?php $this->load->view('template/sidebar');?>

		<div class="main-content">
			<div class="main-content-inner">
				<div class="page-content">
					<div class="row">
						<div class="col-xs-12">
							<!-- PAGE CONTENT BEGINS -->
			
							<div class="widget-box">
								<div class="widget-header widget-header-blue widget-header-flat">
									<h4 class="widget-title lighter">Add Employee</h4>
								</div>

								<div class="widget-body">
									<div class="widget-main">
										<div id="fuelux-wizard-container">
											<div>
												<ul class="steps">
													<li data-step="1" class="active">
														<span class="step">1</span>
														<span class="title">Add Employee</span>
													</li>

													<li data-step="2">
														<span class="step">2</span>
														<span class="title">Salary Details</span>
													</li>

													<li data-step="3">
														<span class="step">3</span>
														<span class="title">Deductions / Recoveries</span>
													</li>

													<li data-step="4">
														<span class="step">4</span>
														<span class="title">Success</span>
													</li>
												</ul>
											</div>

											<hr />
											<div class="step-content pos-rel">
												<div class="step-pane active" data-step="1">
													<?php $this->load->view('employee/step_1')?>
												</div>

												<div class="step-pane" data-step="2">
													<?php $this->load->view('employee/step_2')?>
												</div>

												<div class="step-pane" data-step="3">
													<?php $this->load->view('employee/step_3')?>
												</div>

												<div class="step-pane" data-step="4">
													<div class="center">
														<h3 class="green">Congrats!</h3>
														Your product is ready to ship! Click finish to continue!
													</div>
												</div>
											</div>
										</div>

										<hr />
										<div class="wizard-actions">
											<button class="btn btn-prev">
												<i class="ace-icon fa fa-arrow-left"></i>
												Prev
											</button>

											<button class="btn btn-success btn-next" data-last="Finish">
												Next
												<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
											</button>
										</div>
									</div><!-- /.widget-main -->
								</div><!-- /.widget-body -->
							</div>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.page-content -->
			</div>
		</div><!-- /.main-content -->
	
		<?php $this->load->view('template/footer');?>

		<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
			<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
		</a>
	</div><!-- /.main-container -->
</body>
<script type="text/javascript">
	if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.custom.min.js"></script>
<script src="<?php echo base_url();?>assets/js/wizard.min.js"></script>
<script src="<?php echo base_url();?>assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url();?>assets/js/ace.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
	$('#fuelux-wizard-container').wizard('selectedItem', { step: localStorage.getItem('step') });
});		

$('#fuelux-wizard-container').on('changed.fu.wizard', function(evt, item) {
	var url = $(location).attr('href'),
	    parts = url.split("/"),
	    last_part = parts[parts.length-1];
	
	if(item.step=='1')
	{
		localStorage.setItem('step','1');
	}
	if(item.step=='2')
    {	
    	localStorage.setItem('step','2');
    }
    if(item.step=='3')
    {
    	localStorage.setItem('step','3');
    }
    if(item.step=='4')
    {
    	localStorage.clear();
    	$('.wizard-actions').hide();
    }
});


$('#fuelux-wizard-container')
	.ace_wizard()
	.on('actionclicked.fu.wizard' , function(e, info){
		if(info.step == 1) {
			if(!$('#emp_form').valid()) 
			{
				e.preventDefault();
			}
			else
			{
				$.ajax({
					type:"POST",
					data:$("#emp_form").serialize(),
					url:"<?php echo base_url('employee/insert_emp')?>",
					success: function (res) {
						window.location.href = "<?php echo base_url();?>employee/add_employee/"+btoa(res);
					}
				});
			}
		}
		if(info.step == 2) //Assign questions
		{
			if(!$('#payslip_form').valid()) 
			{
				e.preventDefault();
			}
			else
			{
				$.ajax({
					type:"POST",
					data:$("#payslip_form").serialize(),
					url:"<?php echo base_url('employee/insert_pay')?>",
					success: function (res) {
						//window.location.href = "<?php echo base_url();?>employee/add_employee/"+btoa(res);
					}
				});
			}
		}
		if(info.step == 3) //Assign Users
		{
			if(!$('#ded_form').valid()) 
			{
				e.preventDefault();
			}
			else
			{
				$.ajax({
					type:"POST",
					data:$("#ded_form").serialize(),
					url:"<?php echo base_url('employee/insert_deduction')?>",
					success: function (res) {
						//window.location.href = "<?php echo base_url();?>employee/add_employee/"+btoa(res);
					}
				});
			}
		}
	})
	
	.on('finished.fu.wizard', function(e) {
		bootbox.dialog({
			message: "Thank you! Your information was successfully saved!", 
			buttons: {
				"success" : {
					"label" : "OK",
					"className" : "btn-sm btn-primary"
				}
			}
		});
	}).on('stepclick.fu.wizard', function(e){
		//e.preventDefault();//this will prevent clicking and selecting steps
	});
	
	$('#modal-wizard-container').ace_wizard();
	$('#modal-wizard .wizard-actions .btn[data-dismiss=modal]').removeAttr('disabled');

</script>
</html>
