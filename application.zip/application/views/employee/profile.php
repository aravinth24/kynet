<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta charset="utf-8">
		<title>Kyenet</title>
		<meta name="description" content="User login page">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/4.5.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/fonts.googleapis.com.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace.min.css">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-rtl.min.css">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
		<style type="text/css">
			.profile{
				font-size: 18px;
			}
		</style>
	</head>
	<body class="no-skin">
	<?php $this->load->view('template/header');?>
	<div class="main-container ace-save-state" id="main-container">
		
		<?php $this->load->view('template/sidebar');?>
			
		<div class="main-content">
			<div class="main-content-inner">
				<div class="page-content">
					<div class="page-header">
						<h1>
							<?php echo @$parent;?>
							<?php if(@$child!=''){?>
							<small>
								<i class="ace-icon fa fa-angle-double-right"></i>
								<?php echo $child;?>
							</small>
							<?php } ?>
						</h1>
					</div>

					<div class="row">
						<div class="col-xs-12">
							<table id="emp_table" class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>Employee Id</th>
										<th>Employee Name</th>
										<th>Employee Type</th>
										<th>Experience</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($result as $res){ ?>
										<tr>
											<td><?php echo $res['id'];?></td>
											<td><a href="<?php echo base_url('employee/profile/'.base64_encode($res['id'].'/'.$child))?>"><?php echo $res['username'];?></a></td>
											<td><?php echo $usertype[$res['usertype']];?></td>
											<td><?php echo $res['exp'];?> years</td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.page-content -->
			</div>
		</div>

		<?php $this->load->view('template/footer');?>

		<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
		<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
		</a>
	</div>
</body>

<!--[if !IE]> -->
<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript">
	if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.custom.min.js"></script>	
<script src="<?php echo base_url();?>assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url();?>assets/js/ace.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
$('#emp_table').DataTable();	
</script>

</html>