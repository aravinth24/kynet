<form id="payslip_form" method="post">
	<input type="hidden" name="user_id" value="<?php echo set_value('user_id',@$empdata['id']);?>">
	<?php for($i=0; $i<=12;$i++){?>
	    <div class="form-group">
		      <label for="<?php echo $col2_data[$i]?>"><?php echo $col2_data[$i]?>:</label>
		      <input type="text" class="form-control" id="<?php echo $col2_data[$i]?>" placeholder="<?php echo $col2_data[$i]?>" name="<?php echo $col2_data[$i]?>" value="<?php echo set_value($col2_data[$i],@$paydata[$col2_data[$i]]);?>" >
	    </div>
	<?php } ?>
</form>

<script type="text/javascript">
	$("#payslip_form").validate({
	errorClass:'error_msg',
	rules:{
	<?php for($i=0; $i<=12;$i++){?>
		"<?php echo $col2_data[$i]?>":{
			required: true
		},
	<?php }?>
	},
});
</script>