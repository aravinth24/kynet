<?php
	$select 	 = '<select id="dept_id" name="dept_id" class="form-control">';
	$select 	.=	'<option value="">Select Department</option>';
	foreach ($this->data['menu']  as $key => $value) 
	{
		$selected = ($value['id']==@$empdata['dept_id'])?'selected="selected"':'';
		$select .= '<option value="'.$value['id'].'" '.$selected.'>'.$value['dept_name'].'</option>';
	}
	$select 	.='</select>';
?>
<form class="form-horizontal" id="emp_form" method="post" class="col-md-8">
	<input type="hidden" name="emp_id" id="emp_id" value="<?php echo set_value('emp_id',@$empdata['id']);?>">
	<div class="form-group">
			<label for="employee">Employee Name:</label>
			<input type="text" class="form-control" id="employee" placeholder="Employee Name" name="emp_name" value="<?php echo set_value('employee',@$empdata['username']);?>">
	</div>
		<div class="form-group">
			<label for="department">Department:</label>
			<?php echo $select;?>
	</div>
	<div class="form-group">
			<label for="usertype">Employee type:</label>
			<select id="usertype" name="usertype" class="form-control">
				<option value="">Select Usertype</option>
				<option value="0" <?php echo (@$empdata['usertype']=='0')?'selected="selected"':''?>>Permanent</option>
		      	<option value="1" <?php echo (@$empdata['usertype']=='1')?'selected="selected"':''?>>Contract</option>
		      	<option value="2" <?php echo (@$empdata['usertype']=='2')?'selected="selected"':''?>>Daily Wager</option>
			</select>
	</div>
	<div class="form-group">
	    <label for="employee">Employee Experience:</label>
	    <input type="number" class="form-control" id="exp" placeholder="Employee Experience" name="exp" value="<?php echo set_value('exp',@$empdata['exp']);?>">
	</div>

	<?php for($i=0;$i<count($col_data);$i++){ 	?>
	    	<div class="form-group">
		      	<label for="<?php echo $col_data[$i];?>"><?php echo $col_data[$i];?>:</label>
		      	<input type="text" class="form-control" id="<?php echo $col_data[$i];?>" placeholder="<?php echo $col_data[$i];?>" name="<?php echo $col_data[$i];?>" value="<?php echo set_value($col_data[$i],@$empdata[$col_data[$i]]);?>">
	    	</div>
	<?php } ?>
</form>
<script type="text/javascript">
	$("#emp_form").validate({
	errorClass:'error_msg',
	rules:
	{
		emp_name:
		{
			required: true
		},
		dept_id:
		{
			required: true
		},
		usertype:
		{
			required: true
		},
		exp:
		{
			required: true
		},
		Financial_year:
		{
			required: true
		},

		Month:
		{
			required: true
		},
		Zone:
		{
			required: true
		},
		Section:
		{
			required: true
		},
		Bill_no:
		{
			required: true
		},
		Employee_type:
		{
			required: true
		},
		Salary_type:
		{
			required: true
		},
		Designation:
		{
			required: true
		},
		Bank_name:
		{
			required: true
		},
		Account_number:
		{
			required: true
		},
		PF_contribution:
		{
			required: true
		},
		Pay_type:
		{
			required: true
		},
		Ledger_no:
		{
			required: true
		},
		ML:
		{
			required: true
		},
		CL:
		{
			required: true
		},
		SUS:
		{
			required: true
		},
		N_days:
		{
			required: true
		},
		Absent:
		{
			required: true
		},
	},
	messages:
	{
		emp_name:
		{
			required: "The employee name field is required"
		},
		dept_id:
		{
			required: "The department id field is required"
		},
		usertype:
		{
			required: "The usertype field is required"
		},
		exp:
		{
			required: "The experience field is required"
		},
		Financial_year:
		{
			required: "The financial year field is required"
		},

		Month:
		{
			required: "The month field is required"
		},
		Zone:
		{
			required: "The zone field is required"
		},
		Section:
		{
			required: "The section field is required"
		},
		Bill_no:
		{
			required: "The bill no field is required"
		},
		Employee_type:
		{
			required: "The employee type field is required"
		},
		Salary_type:
		{
			required: "The salary type field is required"
		},
		Designation:
		{
			required: "The designation field is required"
		},
		Bank_name:
		{
			required: "The bank name field is required"
		},
		Account_number:
		{
			required: "The account number field is required"
		},
		PF_contribution:
		{
			required: "The PF contribution field is required"
		},
		Pay_type:
		{
			required: "The pay type field is required"
		},
		Ledger_no:
		{
			required: "The ledger no field is required"
		},
		ML:
		{
			required: "The ML field is required"
		},
		CL:
		{
			required: "The CL field is required"
		},
		SUS:
		{
			required: "The SUS field is required"
		},
		N_days:
		{
			required: "The N_days field is required"
		},
		Absent:
		{
			required: "The absent field is required"
		}
	},
});
</script>