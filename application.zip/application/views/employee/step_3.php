<form id="ded_form" method="post">
	<input type="hidden" name="user_id" value="<?php echo set_value('user_id',@$empdata['id']);?>">
	<div class="col-md-6">
	<?php for($i=13; $i<=28;$i++){?>
	<div class="form-group">
		<label for="<?php echo $col2_data[$i]?>"><?php echo $col2_data[$i]?>:</label>
		<input type="text" class="form-control" id="<?php echo $col2_data[$i]?>" placeholder="<?php echo $col2_data[$i]?>" name="<?php echo $col2_data[$i]?>" value="<?php echo set_value($col2_data[$i],@$deddata[$col2_data[$i]]);?>">
	</div>
	<?php } ?>
	</div>
	<div class="col-md-6">
	<?php for($i=29; $i<=45;$i++){?>
	<div class="form-group">
		<label for="<?php echo $col2_data[$i]?>"><?php echo $col2_data[$i]?>:</label>
		<input type="text" class="form-control" id="<?php echo $col2_data[$i]?>" placeholder="<?php echo $col2_data[$i]?>" name="<?php echo $col2_data[$i]?>" value="<?php echo set_value($col2_data[$i],@$deddata[$col2_data[$i]]);?>">
	</div>
	<?php } ?>
	</div>
</form>
<script type="text/javascript">
	$("#ded_form").validate({
	errorClass:'error_msg',
	rules:{
	<?php for($i=13; $i<=28;$i++){?>
		"<?php echo $col2_data[$i]?>":{
			required: true
		},
	<?php }?>
	},
});
</script>