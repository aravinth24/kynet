<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**********************************************************************************************
 * Filename       : Role_control.php
 * Creation Date  : 24-05-2017
 * Description    : Access controller for the CAP
*********************************************************************************************/	
class Session_control {

	public function index()
	{
		$this->CI = get_instance();
        $router   =& load_class('Router', 'core');
       
        $ctrl 		= $router->fetch_class();
        $function   = $router->fetch_method();

		$excluded_url = ['Login'];
		if(in_array($ctrl,$excluded_url))
		{
			return true;
		}
		if($this->CI->session->userdata('logged_in')!='true')
		{
			redirect(base_url(''));
			return false;
		}
	}
}
/* End of file Session_control.php */
/* Location: ./application/hooks/Session_control.php */