<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**********************************************************************************************
 * Filename       : Employers
 * Database       : indianamemorialgroup
 * Creation Date  : 
 * Author         : 
 * Description    : 
*********************************************************************************************/	
class Security_model extends  CI_Model {
	
	/**
	 * Constructor
	 */	
	
	public function check_user(array $data)
	{
		$table = 'tb_admin';
		$condition = array('username'=>$data['username']);
		#echo  $this->encrypt->encode($data['password']);
		$result =  $this->db->from($table)
							->where($condition)
							->get()
							->row_array();
		if(!empty($result))
		{
			$db_password = $this->encrypt->decode($result['password']);
		
			if($data['password']==$db_password)
			{
				$this->session->set_userdata('user_id',$result['id']);
				$this->session->set_userdata('user_type',$result['user_type']);
				$this->session->set_userdata('username',$result['username']);
				$this->session->set_userdata('logged_in','true');
				return 'success'; 
			}
			else
			{
				return 'invalid_password';
			}
		}
		else
		{
			return 'invalid_credintials';
		}
	}
}

/* Location: ./application/controllers/admin/Employee.php */
?>