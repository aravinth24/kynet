<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('security_model'));
		if($this->session->userdata('logged_in')=='true')
		{
			redirect('Admin/dashboard');
		}
	}
	public function index()
	{
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_error_delimiters("<div class='error_msg'>","</div>");
		if($this->form_validation->run())
		{
			$data = $this->security_model->check_user($_POST);
			switch ($data) 
			{
				case 'success':
					redirect('Admin/dashboard');
					break;

				case 'invalid_password':
					$text ='Invalid Password';
					break;

				case 'invalid_credintials':
					$text ='Invalid login credentials';
					break;
				
				default:
					$text ='';
					break;
			}
			$this->session->set_flashdata('error',$text);
			redirect('');
		}
		$this->load->view('login');
	}
}
