<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __Construct()
	{
		parent::__construct();
		$this->data['menu'] = $this->db->select('*')->from('tb_dept')->get()->result_array();
	}
	public function index()
	{
		redirect('admin/dashboard');
	}

	public function add_department()
	{
		$this->data['parent'] 	= 'Add Department';
		$this->load->view('department/add_dept',$this->data);
	}

	public function insert_dept()
	{
		$dept_name = $this->input->post('department');
		$dept_desc = $this->input->post('desc');
		$this->db->insert('tb_dept',array('dept_name'=>$dept_name,'dept_desc'=>$dept_desc));
	}

	public function content($dept='',$id='')
	{		
		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $dept;

		$this->db->from('tb_users');
		$this->db->where('dept_id',base64_decode($id));
		$result = $this->db->get()->result_array();
		if(!empty($result))
		{
			$col_data = array_slice(array_keys($result[0]),5);
		}
		
		$this->data['usertype'] = array('0'=>'Permanent','1'=>'Contract','2'=>'Daily Wager');

		$this->data['result'] = $result;
		$this->load->view('department/dept_content', $this->data);
	}
}

