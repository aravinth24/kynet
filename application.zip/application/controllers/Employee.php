<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __Construct()
	{
		parent::__construct();
		$this->data['menu'] = $this->db->select('*')->from('tb_dept')->get()->result_array();
	}

	public function index()
	{
		$name = $this->input->post('name');
		$password = $this->input->post('password');
		
		if($name != "" && $password != "")
		{
			//echo 'success';
			$this->dashboard();
		}
		else
		{
			$this->load->view('login');
		}
	}
	
	public function add_employee($edit_id='') //Add employee form
	{
		$this->data['parent'] 	= 'Add Employee';
		$data = $this->db->list_fields('tb_users');
		$this->data['col_data'] 	= array_slice($data,5);
		
		$data = $this->db->list_fields('tb_payment_details');
		$data = array_slice($data,2); 
		$this->data['col2_data'] = $data;

		if($edit_id!='')
		{
			$emp_id = base64_decode($edit_id);
			$this->db->select('usr.*, py.*');
			$this->db->from('tb_users usr');
			$this->db->join('tb_payment_details py','usr.id = user_id','left');
			$this->db->where('usr.id',$emp_id);
			$query = $this->db->get()->row_array();

			$empdata = array_splice($query, 0, 24);
			$paydata = array_splice($query,2,13);
			$deddata = array_splice($query,2);

			$this->data['empdata'] = $empdata;
			$this->data['paydata'] = $paydata;
			$this->data['deddata'] = $deddata;
		}

		$this->load->view('employee/employee_form',$this->data);
	}

	public function insert_emp() //step 1
	{
		$emp_id 	= $this->input->post('emp_id');
		$emp_name 	= $this->input->post('emp_name');
		$dept_id 	= $this->input->post('dept_id');
		$usertype 	= $this->input->post('usertype');
		$exp 		= $this->input->post('exp');

		$data = array('username'=>$emp_name,'dept_id'=>$dept_id,'usertype'=>$usertype,'exp'=>$exp);
		$data = array_merge($data,array_slice($_POST,4));
		//	print_r($data); exit;

		if($emp_id=='')
		{
			$this->db->insert('tb_users',$data);
			echo $this->db->insert_id();
		}
		else if($emp_id!='')
		{
			$this->db->update('tb_users',$data, array('id'=>$emp_id));
			echo $emp_id;
		}
		
	}

	public function insert_pay() //step 2
	{	
		$emp_id = $_POST['user_id'];
		unset($_POST['0']);	

		$get = $this->db->from('tb_payment_details')->where('user_id',$emp_id)->get();
		if($get->num_rows()>0)
		{
			$this->db->update('tb_payment_details',$_POST,array('user_id'=>$emp_id));
		}
		else
		{
			$this->db->insert('tb_payment_details',$_POST);
		}
	}
	
	public function insert_deduction() //step 3
	{	
		$emp_id = $_POST['user_id'];
		unset($_POST['user_id']);	
		unset($_POST['0']);	

		$get = $this->db->from('tb_payment_details')->where('user_id',$emp_id)->get();
		if($get->num_rows()>0)
		{
			$this->db->update('tb_payment_details',$_POST,array('user_id'=>$emp_id));
		}
		else
		{
			$this->db->insert('tb_payment_details',$_POST);
		}
	}

	public function profile($data='')
	{
		$this->data['parent'] 	= 'Department';
		$decode 				= base64_decode($data);
		$res 					= explode('/', $decode);
		$this->data['child'] 	= $res['1'];
		$emp_id 				= $res['0'];			
		
		$query = $this->db->from('tb_users')->where('id',$emp_id)->get()->row_array();
		$this->load->view('employee/profile',$this->data);
	}
	public function profile2($data='')
	{
		$usertype 				= array('0'=>'Permanent','1'=>'Contract','2'=>'Daily Wager');
		$decode 				= base64_decode($data);
		$res 					= explode('/', $decode);
		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $res['3'];

		$payment_pdf 			= ($res['2']=='0')?'sample_salary_slip':'sample_receipt_slip';
		$payment_text 			= ($res['2']=='0')?'Payslip':'Receipt';
		
		if($res['2']=='0')
		{
			$url1 = base_url('users/payslip_view/'.base64_encode($res['0'].'/'.$res['1'].'/'.$res['2'].'/'.$res['3'].'/'.$res['4']));
			$url = '<a href="'.$url1.'">'.$payment_text.'</a>';
		}
		else
		{
			$url = '<a href="'.base_url().'assets/'.$payment_pdf.'.pdf" download>Download '.$payment_text.'</a>';
		}

		$table ='<div class="row">
					<span class="col-md-6 profile"> <b>Name: </b>'.$res['1'].'<hr/> <b>Type: </b>'.$usertype[$res['2']].'<hr/> <b>Experience:</b> '.$res['4'].' Years </span>
				</div><hr/>	';
		$table .='<table id="simple-table" class="table  table-bordered table-hover">
					<thead>
						<tr>
							<th>Month</th>
							<th>No.of Present</th>
							<th>No.of Absent</th>
							<th>Payslip</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>May</td>
							<td>5</td>
							<td>15</td>
							<td>'.$url.'</td>
						</tr>
						<tr>
							<td>June</td>
							<td>3</td>
							<td>17</td>
							<td>'.$url.'</td>
						</tr>
					</tbody>
				</table>';
		$this->data['data'] = $table;
		$this->load->view('dept_content', $this->data);
	}
}
