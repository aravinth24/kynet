<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __Construct()
	{
		parent::__construct();
		
		$this->data['menu'] = $this->db->select('id,dept_name')->from('tb_dept')->get()->result_array();
	}

	public function index()
	{
		$name = $this->input->post('name');
		$password = $this->input->post('password');
		
		if($name != "" && $password != "")
		{
			//echo 'success';
			$this->dashboard();
		}
		else
		{
			$this->load->view('login');
		}
	}
	
	public function profile($data='')
	{
		$usertype 				= array('0'=>'Permanent','1'=>'Contract','2'=>'Daily Wager');
		$decode 				= base64_decode($data);
		$res 					= explode('/', $decode);
		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $res['3'];

		$payment_pdf 			= ($res['2']=='0')?'sample_salary_slip':'sample_receipt_slip';
		$payment_text 			= ($res['2']=='0')?'Payslip':'Receipt';
		
		if($res['2']=='0')
		{
			$url1 = base_url('users/payslip_view/'.base64_encode($res['0'].'/'.$res['1'].'/'.$res['2'].'/'.$res['3'].'/'.$res['4']));
			$url = '<a href="'.$url1.'">'.$payment_text.'</a>';
		}
		else
		{
			$url = '<a href="'.base_url().'assets/'.$payment_pdf.'.pdf" download>Download '.$payment_text.'</a>';
		}

		$table ='<div class="row">
					<span class="col-md-6 profile"> <b>Name: </b>'.$res['1'].'<hr/> <b>Type: </b>'.$usertype[$res['2']].'<hr/> <b>Experience:</b> '.$res['4'].' Years </span>
				</div><hr/>	';
		$table .='<table id="simple-table" class="table  table-bordered table-hover">
					<thead>
						<tr>
							<th>Month</th>
							<th>No.of Present</th>
							<th>No.of Absent</th>
							<th>Payslip</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>May</td>
							<td>5</td>
							<td>15</td>
							<td>'.$url.'</td>
						</tr>
						<tr>
							<td>June</td>
							<td>3</td>
							<td>17</td>
							<td>'.$url.'</td>
						</tr>
					</tbody>
				</table>';
		$this->data['data'] = $table;
		$this->load->view('template/content', $this->data);
	}

	public function add_employee()
	{
		
	}
}
