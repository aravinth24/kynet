<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __Construct()
	{
		parent::__construct();
		$this->data['menu'] = $this->db->select('*')->from('tb_dept')->get()->result_array();
	}
	public function index()
	{
		redirect('admin/dashboard');
	}

	public function dashboard()
	{
		$this->data['parent'] 	= 'Dashboard';
		$this->db->select('u.id,u.username,u.usertype, a.date');
		$this->db->from('tb_users u');
		$this->db->join('tb_user_attendance a','u.id=a.user_id AND a.date ="'.date('Y-m-d').'"','left');
		$this->db->group_by('u.id');
		$query = $this->db->get()->result_array();
		
		$result = array(	'permanent'	 => array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0'),
							'contract'	 => array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0'),
							'daily_wager'=> array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0')
						);
		
		foreach ($query as $key => $value) 
		{
			switch ($value['usertype']) 
			{
				case '0':
						$result['permanent']['total_emp']++;
						if($value['date']!='')
						{
							$result['permanent']['total_present']++;
						}
					break;
				case '1':
						$result['contract']['total_emp']++;
						if($value['date']!='')
						{
							$result['contract']['total_present']++;
						}
					break;
				case '2':
						$result['daily_wager']['total_emp']++;
						if($value['date']!='')
						{
							$result['daily_wager']['total_present']++;
						}
					break;
			}

		}

		$result['permanent']['total_absent'] 	= $result['permanent']['total_emp'] - $result['permanent']['total_present'];
		$result['contract']['total_absent'] 	= $result['contract']['total_emp'] - $result['contract']['total_present'];
		$result['daily_wager']['total_absent'] 	= $result['daily_wager']['total_emp'] - $result['daily_wager']['total_present'];

		$this->data['result'] = $result;
		$this->load->view('dashboard',$this->data);
	}

	public function ajax_data()
	{
		$cat = $this->input->post('category');
		$this->db->select('u.id,u.username,u.usertype, a.date');
		$this->db->from('tb_users u');
		$this->db->join('tb_user_attendance a','u.id=a.user_id AND a.date ="'.date('Y-m-d').'"','left');
		if($cat!='')
		{
			$this->db->where('u.usertype', $cat);
		}
		$this->db->group_by('u.id');
		$query = $this->db->get()->result_array();
		echo '{"data":'.json_encode($query).'}';
		exit;
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('');
	}
}

