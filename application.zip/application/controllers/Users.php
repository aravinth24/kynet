<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __Construct()
	{
		parent::__construct();
		
		$this->data['menu'] = $this->db->select('id,dept_name')->from('tb_departments')->get()->result_array();
	}

	public function index()
	{
		$name = $this->input->post('name');
		$password = $this->input->post('password');
		
		if($name != "" && $password != "")
		{
			//echo 'success';
			$this->dashboard();
		}
		else
		{
			$this->load->view('login');
		}
	}
	
	public function dashboard()
	{
		$this->db->select('u.id,u.username,u.usertype, a.date');
		$this->db->from('tb_users u');
		$this->db->join('tb_user_attendance a','u.id=a.user_id AND a.date ="'.date('Y-m-d').'"','left');
		$this->db->group_by('u.id');
		$query = $this->db->get()->result_array();
		
		$result = array(	'permanent'	 => array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0'),
							'contract'	 => array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0'),
							'daily_wager'=> array('total_emp' => '0','total_present'=>'0' , 'total_absent'=>'0')
						);
		
		foreach ($query as $key => $value) 
		{
			switch ($value['usertype']) 
			{
				case '0':
						$result['permanent']['total_emp']++;
						if($value['date']!='')
						{
							$result['permanent']['total_present']++;
						}
					break;
				case '1':
						$result['contract']['total_emp']++;
						if($value['date']!='')
						{
							$result['contract']['total_present']++;
						}
					break;
				case '2':
						$result['daily_wager']['total_emp']++;
						if($value['date']!='')
						{
							$result['daily_wager']['total_present']++;
						}
					break;
			}

		}

		$result['permanent']['total_absent'] 	= $result['permanent']['total_emp'] - $result['permanent']['total_present'];
		$result['contract']['total_absent'] 	= $result['contract']['total_emp'] - $result['contract']['total_present'];
		$result['daily_wager']['total_absent'] 	= $result['daily_wager']['total_emp'] - $result['daily_wager']['total_present'];

		$this->data['result'] = $result;
		$this->load->view('dashboard',$this->data);
	}

	public function add_department()
	{
		$this->data['parent'] 	= 'Add department';
		$this->data['data'] 	= '<form id="dept_form" method="post" class="col-md-8">
									    <div class="form-group">
									      <label for="department">Department Name:</label>
									      <input type="text" class="form-control" id="department" placeholder="Enter department" name="department" required>
									    </div>
									   <div class="form-group">
									      <label for="department">Department Desciption:</label>
									      <textarea class="form-control" placeholder="Enter Desciption" id="desc" name="desc" required></textarea>
									    </div>
									    <button type="submit" class="btn btn-default">Submit</button>
									</form>';
		$this->load->view('template/content',$this->data);
	}

	public function insert_dept()
	{
		$dept_name = $this->input->post('department');
		$dept_desc = $this->input->post('desc');

		$this->db->insert('tb_departments',array('dept_name'=>$dept_name,'dept_desc'=>$dept_desc));
	}

	public function add_employee()
	{
		$data = $this->db->list_fields('tb_users');

		$this->data['parent'] 	= 'Add Employee';
		$this->data['col_data'] 	= array_slice($data,5);

		$this->load->view('add_employee',$this->data);
	}

	public function insert_emp()
	{
		//print_r($_POST); exit;
		$emp_name 	= $this->input->post('emp_name');
		$dept_id 	= $this->input->post('dept_id');
		$usertype 	= $this->input->post('usertype');
		$exp 		= $this->input->post('exp');

		$data = array('username'=>$emp_name,'dept_id'=>$dept_id,'usertype'=>$usertype,'exp'=>$exp);
		$data = array_merge($data,array_slice($_POST,3));
		//	print_r($data); exit;
		$this->db->insert('tb_users',$data);
	}
	public function content($dept='',$id='')
	{		
		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $dept;

		$this->db->from('tb_users');
		$this->db->where('dept_id',base64_decode($id));
		$result = $this->db->get()->result_array();
		if(!empty($result))
		{
			$col_data = array_slice(array_keys($result[0]),5);
		}
		
		$usertype = array('0'=>'Permanent','1'=>'Contract','2'=>'Daily Wager');

		$table 	= '<div style="overflow-x:auto;"><table id="simple-table" class="table  table-bordered table-hover">';
		$table .= '<thead>
						<tr>
							<th>Employee Id</th>
							<th>Employee Name</th>
							<th>Employee Type</th>
							<th>Experience</th>';
		
		//echo $loop_data;exit;
		$table .= '</tr></thead><tbody>';

		if(!empty($result)){					
			foreach ($result as $k => $v) {
				$table .= '<tr>
								<td>'.$v['id'].'</td>
								<td><a href="'.base_url('users/profile/'.base64_encode($v['id'].'/'.$v['username'].'/'.$v['usertype'].'/'.$dept.'/'.$v['exp'])).'">'.$v['username'].'</a></td>
								<td>'.$usertype[$v['usertype']].'</td>
								<td>'.$v['exp'].' years </td>
							</tr>';
			}
		}
		else
		{
			$table .= '<tr><td colspan="5"	>No records found</td></tr>';
		}
		$table .= '</tbody></table></div>';

		$this->data['data'] = $table;
		$this->load->view('template/content', $this->data);
	}

	public function payslip_form($id='')
	{
		$this->data['parent'] 	= 'Update Payslip';
		$this->data['user_id'] = base64_decode($id);
		$data = $this->db->list_fields('tb_payment_details');
		$data = array_slice($data,2); 
		$this->data['col_data'] = $data;
		$this->load->view('payslip_form', $this->data);
	}
	public function insert_payslip()
	{	
		$this->db->delete('tb_payment_details',array('user_id'=>$_POST['user_id']));
		unset($_POST['0']);		
		$this->db->insert('tb_payment_details',$_POST);
	}
	public function gen_pdf($id='')
	{
		$user_id = base64_decode($id);
		$this->db->from('tb_users u');
		$this->db->join('tb_payment_details pd','u.id = pd.user_id','left');
		$this->db->where('u.id',$user_id);
		$this->data['res'] = $this->db->get()->row_array();
		$this->load->view('payslip_data', $this->data);

  		//exec('wkhtmltopdf '.$html.' test.pdf');
  		//echo '<script type="text/javascript">window.print();</script>';
	}
	public function payslip_view($data='')
	{
		$decode 				= base64_decode($data);
		$res 					= explode('/', $decode);

		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $res['3'];

		
		$this->db->from('tb_users u');
		$this->db->join('tb_payment_details pd','u.id = pd.user_id','left');
		$this->db->where('u.id',$res['0']);
		$this->data['res'] = $this->db->get()->row_array();
		$this->load->view('payslip_view',$this->data);
	}
	public function profile($data='')
	{
		$usertype 				= array('0'=>'Permanent','1'=>'Contract','2'=>'Daily Wager');
		$decode 				= base64_decode($data);
		$res 					= explode('/', $decode);
		$this->data['parent'] 	= 'Department';
		$this->data['child'] 	= $res['3'];

		$payment_pdf 			= ($res['2']=='0')?'sample_salary_slip':'sample_receipt_slip';
		$payment_text 			= ($res['2']=='0')?'Payslip':'Receipt';
		
		if($res['2']=='0')
		{
			$url1 = base_url('users/payslip_view/'.base64_encode($res['0'].'/'.$res['1'].'/'.$res['2'].'/'.$res['3'].'/'.$res['4']));
			$url = '<a href="'.$url1.'">'.$payment_text.'</a>';
		}
		else
		{
			$url = '<a href="'.base_url().'assets/'.$payment_pdf.'.pdf" download>Download '.$payment_text.'</a>';
		}

		$table ='<div class="row">
					<span class="col-md-6 profile"> <b>Name: </b>'.$res['1'].'<hr/> <b>Type: </b>'.$usertype[$res['2']].'<hr/> <b>Experience:</b> '.$res['4'].' Years </span>
				</div><hr/>	';
		$table .='<table id="simple-table" class="table  table-bordered table-hover">
					<thead>
						<tr>
							<th>Month</th>
							<th>No.of Present</th>
							<th>No.of Absent</th>
							<th>Payslip</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>May</td>
							<td>5</td>
							<td>15</td>
							<td>'.$url.'</td>
						</tr>
						<tr>
							<td>June</td>
							<td>3</td>
							<td>17</td>
							<td>'.$url.'</td>
						</tr>
					</tbody>
				</table>';
		$this->data['data'] = $table;
		$this->load->view('template/content', $this->data);
	}
	
	public function logout()
	{
		$this->load->view('login');
	}

	public function employee_list()
	{
		$this->load->view('employee_list');
	}

	public function ajax_data()
	{
		$cat = $this->input->post('category');
		$this->db->select('u.id,u.username,u.usertype, a.date');
		$this->db->from('tb_users u');
		$this->db->join('tb_user_attendance a','u.id=a.user_id AND a.date ="'.date('Y-m-d').'"','left');
		if($cat!='')
		{
			$this->db->where('u.usertype', $cat);
		}
		$this->db->group_by('u.id');
		$query = $this->db->get()->result_array();
		echo '{"data":'.json_encode($query).'}';
		exit;
	}
}
